// Effetti per la Navbar sticky e animazione di scorrimento
window.addEventListener('scroll', function() {
    // Seleziona la navbar dall'HTML
    const navbar = document.querySelector('.navbar');
    // Aggiungi la classe 'scrolled' se l'utente ha scrollato oltre i 50px
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        // Rimuovi la classe 'scrolled' se l'utente è tornato in cima
        navbar.classList.remove('scrolled');
    }
});

// Scroll Animato per i link della navbar
document.querySelectorAll('.nav-link').forEach(link => {
    // Aggiunge un evento click a ciascun link nella navbar
    link.addEventListener('click', function(e) {
        e.preventDefault(); // Previene il comportamento predefinito del link
        // Seleziona l'elemento corrispondente all'ID dal link
        const target = document.querySelector(this.getAttribute('href'));
        // Esegue uno scroll liscio fino all'elemento selezionato
        target.scrollIntoView({ behavior: 'smooth' });
    });
});

// Gestione del form
document.querySelector('#contactForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Previene il comportamento predefinito del form (refresh della pagina)
    // Prende i valori dei campi del form
    const name = document.querySelector('#name').value;
    const email = document.querySelector('#email').value;
    const message = document.querySelector('#message').value;

    // Verifica se tutti i campi sono compilati
    if (name && email && message) {
        // Se i campi sono validi, mostra un messaggio di conferma
        document.querySelector('#formResult').innerHTML = '<p>Grazie per averci contattato!</p>';
    } else {
        // Se mancano dei campi, richiede di compilare tutti i campi
        document.querySelector('#formResult').innerHTML = '<p>Per favore, compila tutti i campi.</p>';
    }
});

// Funzione per ottenere l'IP dell'utente tramite un'API esterna
async function getUserIP() {
    const response = await fetch('https://api64.ipify.org?format=json');
    const data = await response.json();
    return data.ip; // Ritorna l'indirizzo IP dell'utente
}

// Gestione del form con l'invio dei dati a Discord
document.querySelector('#contactForm').addEventListener('submit', async function(e) {
    e.preventDefault(); // Previene il comportamento predefinito del form

    // Ottieni i dati dal form
    const name = document.querySelector('#name').value;
    const email = document.querySelector('#email').value;
    const message = document.querySelector('#message').value;
    const userIP = await getUserIP();  // Ottieni l'IP dell'utente tramite l'API

    // Verifica se tutti i campi del form sono compilati
    if (name && email && message) {
        // URL del webhook Discord per inviare il messaggio
        const discordWebhookUrl = 'https://discord.com/api/webhooks/1291658384516579329/fku3OspqG1GhuD94n1PGRfkQajAa7V6n3bXixvcCXVF7wBps7BKWC9jsYffdoePqKeju'; 
        
        // Costruisce i dati da inviare a Discord con un embed personalizzato
        const embedData = {
            username: "Contact Form Bot",  // Nome visualizzato su Discord
            avatar_url: "https://i.imgur.com/4M34hi2.png", // URL di un'icona per il bot
            embeds: [
                {
                    title: "Nuovo messaggio dal form di contatto", // Titolo del messaggio
                    color: 3447003,  // Colore dell'embed
                    fields: [
                        { name: "Nome", value: name, inline: true },
                        { name: "Email", value: email, inline: true },
                        { name: "Messaggio", value: message, inline: false },
                        { name: "IP Utente", value: userIP, inline: false } // Mostra l'IP dell'utente
                    ],
                    footer: {
                        text: `Inviato il ${new Date().toLocaleString()}` // Aggiunge la data e l'ora
                    }
                }
            ]
        };

        // Prova a inviare i dati a Discord tramite fetch
        try {
            const response = await fetch(discordWebhookUrl, {
                method: 'POST', // Metodo HTTP POST
                headers: {
                    'Content-Type': 'application/json', // Specifica il tipo di contenuto come JSON
                },
                body: JSON.stringify(embedData), // Converte i dati in formato JSON
            });
            
            if (response.ok) {
                // Se l'invio è riuscito, mostra un messaggio di conferma
                document.querySelector('#formResult').innerHTML = '<p>Grazie per averci contattato! Il tuo messaggio è stato inviato con successo.</p>';
            } else {
                // Se c'è un errore nella risposta di Discord, mostra un messaggio di errore
                document.querySelector('#formResult').innerHTML = '<p>C\'è stato un errore durante l\'invio del messaggio. Riprova più tardi.</p>';
                console.error('Errore risposta Discord:', response.statusText);
            }
        } catch (error) {
            // Se c'è un errore nella connessione, mostra un messaggio di errore
            document.querySelector('#formResult').innerHTML = '<p>Errore di connessione. Controlla la tua rete e riprova.</p>';
            console.error('Errore durante l\'invio al webhook Discord:', error);
        }
    } else {
        // Se i campi non sono compilati, richiede di compilare tutti i campi
        document.querySelector('#formResult').innerHTML = '<p>Per favore, compila tutti i campi.</p>';
    }
});

// Funzione per controllare se una pagina esiste
function checkPageExists(url) {
    return fetch(url, { method: 'HEAD' }) // Esegue una richiesta HEAD per verificare l'esistenza della pagina
        .then(response => response.status !== 404); // Se la risposta non è 404, la pagina esiste
}

// Controlla la pagina attuale
const currentPage = window.location.pathname;

// Verifica se la pagina esiste
checkPageExists(currentPage).then(exists => {
    if (!exists) {
        // Se la pagina non esiste, reindirizza a 404.html
        window.location.href = '404.html';
    }
});
